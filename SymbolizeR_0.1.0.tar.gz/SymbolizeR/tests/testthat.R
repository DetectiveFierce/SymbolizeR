# This file is part of the standard testthat setup.
# It is automatically run when testing the package.

library(testthat)
library(SymbolizeR)

test_check("SymbolizeR")
